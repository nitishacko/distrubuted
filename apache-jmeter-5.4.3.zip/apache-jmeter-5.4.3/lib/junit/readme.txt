This directory is for jars to be used with the JUnit Sampler.
